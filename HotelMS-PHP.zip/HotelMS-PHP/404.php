<?php

include_once "header.php";
include_once "sidebar.php";
?>
<center><h1>404 Error Page</h1></center>
